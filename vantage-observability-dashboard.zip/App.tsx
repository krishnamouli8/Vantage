
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StatCard from './components/StatCard';
import ThroughputChart from './components/ThroughputChart';
import ServiceHealth from './components/ServiceHealth';
import AlertsTable from './components/AlertsTable';
import AIInsights from './components/AIInsights';

const App: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  return (
    <div className="flex h-screen w-full bg-background-light dark:bg-background-dark transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <Header onToggleDarkMode={toggleDarkMode} isDarkMode={isDarkMode} />
        
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
          <div className="max-w-7xl mx-auto space-y-7">
            {/* Top Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
              <StatCard 
                label="Total Requests" 
                value="2.4M" 
                trend="12%" 
                trendDirection="up" 
                icon="bolt" 
                colorClass="text-orange-400 bg-orange-400/10" 
              />
              <StatCard 
                label="Avg. Latency" 
                value="124ms" 
                trend="5ms" 
                trendDirection="down" 
                icon="timer" 
                colorClass="text-blue-400 bg-blue-400/10" 
              />
              <StatCard 
                label="Error Rate" 
                value="0.04%" 
                trend="stable" 
                trendDirection="neutral" 
                icon="error_outline" 
                colorClass="text-red-400 bg-red-400/10" 
              />
              <StatCard 
                label="Active Services" 
                value="14" 
                trend="+2 new" 
                trendDirection="up" 
                icon="storage" 
                colorClass="text-orange-400 bg-orange-400/10" 
              />
            </div>

            {/* Middle Section: Chart and Service Health */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <ThroughputChart />
                <AIInsights />
              </div>
              <ServiceHealth />
            </div>

            {/* Bottom Section: Alerts */}
            <AlertsTable />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
