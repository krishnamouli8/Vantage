
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

const AIInsights: React.FC = () => {
  const [insight, setInsight] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  const fetchInsight = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are a DevOps and Observability expert. Based on these dashboard metrics:
        - Total Requests: 2.4M (+12%)
        - Avg Latency: 124ms (-5ms)
        - Error Rate: 0.04% (stable)
        - Recent Alert: Critical Auth Service Latency >500ms
        
        Provide a concise, 2-sentence actionable insight for the site reliability team. Focus on the anomaly.`,
      });
      setInsight(response.text || 'Unable to generate insight at this time.');
    } catch (err) {
      console.error('Gemini error:', err);
      setInsight('AI system currently offline. Monitor Auth Service latency manually.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInsight();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="bg-gradient-to-br from-orange-50 to-white dark:from-orange-950/20 dark:to-surface-dark p-6 rounded-2xl shadow-soft border border-orange-100 dark:border-orange-900/30 flex items-start gap-4">
      <div className="bg-orange-100 dark:bg-orange-500/20 p-3 rounded-xl shrink-0">
        <span className="material-icons-round text-orange-500 text-2xl">psychology</span>
      </div>
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">Vantage AI Insight</h4>
          {loading && <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>}
        </div>
        <p className={`text-sm leading-relaxed ${loading ? 'text-slate-400 italic' : 'text-slate-600 dark:text-slate-300'}`}>
          {loading ? 'Analyzing system metrics...' : insight}
        </p>
      </div>
    </div>
  );
};

export default AIInsights;
