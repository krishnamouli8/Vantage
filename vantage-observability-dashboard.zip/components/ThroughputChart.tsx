
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceDot } from 'recharts';

const data = [
  { time: '10:00', rps: 240 },
  { time: '10:10', rps: 310 },
  { time: '10:20', rps: 280 },
  { time: '10:30', rps: 350 },
  { time: '10:40', rps: 320 },
  { time: '10:50', rps: 410 },
  { time: '11:00', rps: 380 },
  { time: '11:10', rps: 450 },
  { time: '11:20', rps: 324 },
  { time: '11:30', rps: 410 },
  { time: '11:40', rps: 380 },
  { time: '11:50', rps: 480 },
];

const ThroughputChart: React.FC = () => {
  return (
    <div className="bg-surface-light dark:bg-surface-dark p-7 rounded-2xl border border-slate-100 dark:border-border-dark flex flex-col h-[420px]">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Throughput</h2>
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Requests per second over time</p>
        </div>
        <div className="flex items-center bg-slate-50 dark:bg-[#111] border border-slate-200 dark:border-border-dark rounded-lg px-3 py-1.5 cursor-pointer">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">Last 1 Hour</span>
          <span className="material-icons-round text-sm ml-2 text-slate-400">expand_more</span>
        </div>
      </div>
      
      <div className="flex-1 w-full relative">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 20, right: 0, left: -25, bottom: 0 }}>
            <defs>
              <linearGradient id="colorRps" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f97316" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f1f1f" />
            <XAxis 
              dataKey="time" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fontSize: 10, fill: '#4b5563', fontWeight: 600 }} 
              dy={15}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fontSize: 10, fill: '#4b5563', fontWeight: 600 }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#111', 
                border: '1px solid #1f1f1f', 
                borderRadius: '8px', 
                color: '#fff',
                fontSize: '11px'
              }}
              itemStyle={{ color: '#f97316' }}
              cursor={{ stroke: '#f97316', strokeWidth: 1 }}
            />
            <Area 
              type="monotone" 
              dataKey="rps" 
              stroke="#f97316" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorRps)" 
              animationDuration={1500}
            />
            {/* Custom high point marker */}
            <ReferenceDot x="11:20" y={324} r={4} fill="#fff" stroke="#f97316" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
        
        <div className="absolute top-[58%] left-[64%] bg-white text-black px-2 py-1 rounded shadow-lg text-[10px] font-bold pointer-events-none">
            324 RPS
        </div>
      </div>
    </div>
  );
};

export default ThroughputChart;
